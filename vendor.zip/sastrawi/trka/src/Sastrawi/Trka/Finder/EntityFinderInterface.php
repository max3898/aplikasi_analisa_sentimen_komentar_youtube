<?php

namespace Sastrawi\Trka\Finder;

interface EntityFinderInterface
{
    public function find($text);
}
