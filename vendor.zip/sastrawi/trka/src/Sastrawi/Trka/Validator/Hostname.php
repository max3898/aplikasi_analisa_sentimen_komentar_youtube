<?php

namespace Sastrawi\Trka\Validator;

use Zend\Validator\Hostname as ZendHostnameValidator;

class Hostname extends ZendHostnameValidator implements ValidatorInterface
{
}
