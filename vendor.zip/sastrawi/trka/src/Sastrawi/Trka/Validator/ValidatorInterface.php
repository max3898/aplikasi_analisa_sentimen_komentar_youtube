<?php

namespace Sastrawi\Trka\Validator;

interface ValidatorInterface
{
    public function isValid($value);
}
